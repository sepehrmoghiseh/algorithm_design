import random
import operator


class Cube:
    def __init__(self, color, weight, used):
        self.color = color
        self.weight = weight
        self.used = used

    def set_used(self, used):
        self.used = used


colors = ["blue", "red", "green", "yellow"]
cubes = []
for i in range(10):
    sides = []
    for i in range(6):
        sides.append(random.choice(colors))

    cubes.append(Cube(sides, random.randint(1, 100), False))

tower = {}
sorted_cubes = sorted(cubes, key=operator.attrgetter('weight'), reverse=True)

tower[1] = sorted_cubes[0]

for i in range(1, len(sorted_cubes)):
    maximum = []
    for key, value in tower.items():
        if value.color[0] == sorted_cubes[i].color[5]:
            maximum.append(key)
    if maximum != []:
        tower[max(maximum) + 1] = sorted_cubes[i]
for i in sorted_cubes:
    print(i.color[0]+" "+i.color[5]+" "+ str(i.weight))
print(tower.keys())
for value in tower.values():
    print(value.color[0]+ " "+ value.color[5]+ str(value.weight))