if __name__ == "__main__":
    sum = int(input())
    arr = map(int, input().split())

    visited = set()
    for i in arr:
        if (sum - i) in visited:
            print(f"{i}, {sum - i}")
        
        visited.add(i)
