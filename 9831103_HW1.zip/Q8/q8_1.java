import java.util.*;

class GFG {
    static String findPair(int a[], int n, int k){
        for (int i = 0; i <n ; i++) {
            for (int j = i+1; j <n ; j++) {
                if(a[i]+a[j]==k){
                    return "yes";
                }
            }
        }
        return "no";
    }

    public static void main(String args[])
    {
        int a[]={1,-2,5,22,-3};
        int n=a.length;
        int k=7;
        System.out.println(findPair(a,n,k));
    }
}
